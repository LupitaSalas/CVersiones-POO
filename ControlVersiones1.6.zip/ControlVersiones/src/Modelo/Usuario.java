/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Modelo;

/**
 *
 * @author lupit
 */
public class Usuario {
    private String nombre;
    private String apellidoPaterno;
    private String apellidoMaterno;
    private String clave;
    
    
    public Usuario(String nombre, String apellidoPaterno, String apellidoMaterno,String clave){
        this.nombre = nombre;
        this.apellidoPaterno = apellidoPaterno;
        this.apellidoMaterno = apellidoMaterno;
        this.clave = clave;
    }
    
    public String getNombre(){
        return nombre;
    } 
    public String getApellidoPaterno(){
        return apellidoPaterno;
    } 
    public String getApellidoMaterno(){
        return apellidoMaterno;
    } 
    public String getClave(){
        return clave;
    }
    
    public void setNombre(String nombre){
        this.nombre = nombre;
    }
    public void setApellidoPaterno(String apellidoPaterno){
        this.apellidoPaterno = apellidoPaterno ;
    }
    public void setApellidoMaterno(String apellidoMaterno){
        this.apellidoMaterno = apellidoMaterno ;
    }
    public void setClave(String clave){
        this.clave = clave;
    }
    
    @Override
    public String toString() {
        return  
                "\nNombre = " + getNombre() + 
                "\nApellido Paterno = " + getApellidoPaterno() + 
                "\nApellido Materno = " + getApellidoMaterno() +
                "\nClave = " + getClave();
    }
   
    
}
