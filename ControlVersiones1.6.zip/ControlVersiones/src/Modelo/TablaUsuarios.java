/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Modelo;

import Aplicacion.MainControl;
import java.util.ArrayList;
import java.util.Vector;
import javax.swing.JTable;
import javax.swing.table.DefaultTableModel;

/**
 *
 * @author gmg_9
 */
public class TablaUsuarios {
    public ArrayList<Usuario> listaUsuarios = new ArrayList<Usuario>();
    
    public void agregarUsuario(String nombre, String apellidoPaterno, String apellidoMaterno, String clave ){
    
        listaUsuarios.add(new Usuario(nombre, apellidoPaterno, apellidoMaterno, clave));
    }
    public void eliminarUsuario(int indice){
        listaUsuarios.remove(indice);
    }
    public void inicializaTabla(JTable tabla){
        Vector<String> titulos = new Vector<String>();
        Vector<Vector<Object> > data = new Vector <Vector <Object>>();
        
        //Se ingresan datos en titulos
        titulos.add("Nombre");
        titulos.add("Apellido Paterno");
        titulos.add("Username");
        
        //Ciclo para ingresar los datos en data
        //for(int i = 0; i<listEmpleados.size(); i++){
        for(int i = 0; i<MainControl.listaUsuarios.size(); i++){
            Vector<Object> row = new Vector<Object>();
            row.add( ((Usuario)MainControl.listaUsuarios.get(i)).getNombre());
            row.add( ((Usuario)MainControl.listaUsuarios.get(i)).getApellidoPaterno());
            row.add( ((Usuario)MainControl.listaUsuarios.get(i)).getApellidoMaterno());
            row.add( ((Usuario)MainControl.listaUsuarios.get(i)).getClave());
            data.add(row);
        }
        DefaultTableModel modelo = new javax.swing.table.DefaultTableModel(data,titulos);
        tabla.setModel(modelo);
    }
}
