/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Modelo;

import Controlador.CtrlArchivo;

import javax.swing.filechooser.FileNameExtensionFilter;

/**
 *
 * @author rekum
 */
public class Archivo extends Repositorio{
    private Fecha fecha;
    private CtrlArchivo unCtrlArchivo;
    private FileNameExtensionFilter filtro = new FileNameExtensionFilter("Archivos texto", "txt");

    public CtrlArchivo getUnCtrlArchivo() {
        return unCtrlArchivo;
    }

    public void setUnCtrlArchivo(CtrlArchivo unCtrlArchivo) {
        this.unCtrlArchivo = unCtrlArchivo;
    }

    public Archivo(String nombre, String ubicacion,String tipo, Fecha fecha) {
        super(nombre, ubicacion, tipo);
        this.fecha = fecha;
    }

    public Fecha getFecha() {
        return fecha;
    }

    public void setFecha(Fecha fecha) {
        this.fecha = fecha;
    }
  
   }
            
            
            
    
   
