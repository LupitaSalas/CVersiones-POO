
package Vista;

import Modelo.Repositorio;
import java.awt.Desktop;
import java.awt.FileDialog;
import java.io.File;
import java.io.FileWriter;
import java.io.IOException;
import java.nio.file.Files;
import java.nio.file.Paths;
import java.util.Scanner;
import java.util.logging.Level;
import java.util.logging.Logger;
import javax.swing.JFileChooser;
import javax.swing.JOptionPane;
import javax.swing.filechooser.FileNameExtensionFilter;


public class FrmCrearProyecto extends javax.swing.JFrame {
    private FileNameExtensionFilter filtro = new FileNameExtensionFilter("Archivos texto", "txt");

    
    public FrmCrearProyecto() {
        initComponents();
    }

    
    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        jLabel3 = new javax.swing.JLabel();
        texNombreRepo = new javax.swing.JTextField();
        jLabel1 = new javax.swing.JLabel();
        cajaOpcionesTipoRepo = new javax.swing.JComboBox<>();
        btnGuardarProyecto = new javax.swing.JButton();
        btnSalirProyecto = new javax.swing.JButton();
        btnBuscar = new javax.swing.JButton();
        lbRuta = new javax.swing.JLabel();
        txtRuta = new javax.swing.JTextField();

        setDefaultCloseOperation(javax.swing.WindowConstants.EXIT_ON_CLOSE);

        jLabel3.setText("Nombre del repositorio:");

        jLabel1.setText("Tipo de repositorio: ");

        cajaOpcionesTipoRepo.setModel(new javax.swing.DefaultComboBoxModel<>(new String[] { "Documento", "Código", "Proyecto", "Misceláneo" }));

        btnGuardarProyecto.setText("Crear");
        btnGuardarProyecto.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                btnGuardarProyectoMouseClicked(evt);
            }
        });

        btnSalirProyecto.setText("Salir");
        btnSalirProyecto.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                btnSalirProyectoMouseClicked(evt);
            }
        });

        btnBuscar.setText("Buscar");
        btnBuscar.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                btnBuscarMouseClicked(evt);
            }
        });

        lbRuta.setText("Ruta del Archivo:");

        javax.swing.GroupLayout layout = new javax.swing.GroupLayout(getContentPane());
        getContentPane().setLayout(layout);
        layout.setHorizontalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(layout.createSequentialGroup()
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(layout.createSequentialGroup()
                        .addGap(74, 74, 74)
                        .addComponent(btnBuscar)
                        .addGap(62, 62, 62)
                        .addComponent(btnGuardarProyecto, javax.swing.GroupLayout.PREFERRED_SIZE, 79, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addGap(64, 64, 64)
                        .addComponent(btnSalirProyecto, javax.swing.GroupLayout.PREFERRED_SIZE, 71, javax.swing.GroupLayout.PREFERRED_SIZE))
                    .addGroup(layout.createSequentialGroup()
                        .addContainerGap()
                        .addComponent(jLabel3)
                        .addGap(18, 18, 18)
                        .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addComponent(txtRuta)
                            .addComponent(texNombreRepo))))
                .addGap(65, 65, 65))
            .addGroup(layout.createSequentialGroup()
                .addContainerGap()
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(layout.createSequentialGroup()
                        .addComponent(jLabel1)
                        .addGap(34, 34, 34)
                        .addComponent(cajaOpcionesTipoRepo, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                    .addComponent(lbRuta))
                .addGap(0, 0, Short.MAX_VALUE))
        );
        layout.setVerticalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(layout.createSequentialGroup()
                .addGap(13, 13, 13)
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(lbRuta)
                    .addComponent(txtRuta, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addGap(18, 18, 18)
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jLabel3, javax.swing.GroupLayout.PREFERRED_SIZE, 17, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(texNombreRepo, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, 22, Short.MAX_VALUE)
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jLabel1)
                    .addComponent(cajaOpcionesTipoRepo, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addGap(46, 46, 46)
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(btnGuardarProyecto)
                    .addComponent(btnSalirProyecto)
                    .addComponent(btnBuscar))
                .addGap(22, 22, 22))
        );

        pack();
    }// </editor-fold>//GEN-END:initComponents

    private void btnGuardarProyectoMouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_btnGuardarProyectoMouseClicked
        String ubicacion;
        try {
            Files.createDirectories(Paths.get(""));
        } catch (IOException ex) {
            Logger.getLogger(FrmCrearProyecto.class.getName()).log(Level.SEVERE, null, ex);
        }
    }//GEN-LAST:event_btnGuardarProyectoMouseClicked

    private void btnBuscarMouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_btnBuscarMouseClicked
        
        //Muestra el cuadro de dialogo para que el usuario pueda elegir el archivo
          JFileChooser file = new JFileChooser();
        file.setFileFilter(filtro);  //Filtro para que salgan de primera instancia de los archivos que necesita el usuario
        file.setFileSelectionMode(JFileChooser.FILES_AND_DIRECTORIES);
        
        //Muestra la acion del usuario
        int opcion = file.showOpenDialog(this);
        // muestra error si es inválido
        //if ((archivo == null) || (archivo.getName().equals(""))) {
          //JOptionPane.showMessageDialog(this, "Nombre de archivo inválido", "Nombre de archivo inválido", JOptionPane.ERROR_MESSAGE);
        //} // fin de if
        //analizamos la respuesta
         switch(opcion) {
         case JFileChooser.APPROVE_OPTION:
         //seleccionó abrir
         break;

         case JFileChooser.CANCEL_OPTION:
         //dio click en cancelar o cerro la ventana
         break;
         case JFileChooser.ERROR_OPTION:
         //llega aqui si sucede un error
          break;
         }
         File archivo= file.getSelectedFile(); // obtiene el archivo seleccionado
         //y guardar una ruta
         String ruta = archivo.getPath();    
         this.txtRuta.setText(unCtrlArchivo.BuscarArchivo(ruta));
        
        
 
    }//GEN-LAST:event_btnBuscarMouseClicked

    private void btnSalirProyectoMouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_btnSalirProyectoMouseClicked
        // TODO add your handling code here:
        this.dispose();
    }//GEN-LAST:event_btnSalirProyectoMouseClicked

    /**
     * @param args the command line arguments
     */
    public static void main(String args[]) {
        /* Set the Nimbus look and feel */
        //<editor-fold defaultstate="collapsed" desc=" Look and feel setting code (optional) ">
        /* If Nimbus (introduced in Java SE 6) is not available, stay with the default look and feel.
         * For details see http://download.oracle.com/javase/tutorial/uiswing/lookandfeel/plaf.html 
         */
        try {
            for (javax.swing.UIManager.LookAndFeelInfo info : javax.swing.UIManager.getInstalledLookAndFeels()) {
                if ("Nimbus".equals(info.getName())) {
                    javax.swing.UIManager.setLookAndFeel(info.getClassName());
                    break;
                }
            }
        } catch (ClassNotFoundException ex) {
            java.util.logging.Logger.getLogger(FrmCrearProyecto.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (InstantiationException ex) {
            java.util.logging.Logger.getLogger(FrmCrearProyecto.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (IllegalAccessException ex) {
            java.util.logging.Logger.getLogger(FrmCrearProyecto.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (javax.swing.UnsupportedLookAndFeelException ex) {
            java.util.logging.Logger.getLogger(FrmCrearProyecto.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        }
        //</editor-fold>

        /* Create and display the form */
        java.awt.EventQueue.invokeLater(new Runnable() {
            public void run() {
                new FrmCrearProyecto().setVisible(true);
            }
        });
    }

    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JButton btnBuscar;
    private javax.swing.JButton btnGuardarProyecto;
    private javax.swing.JButton btnSalirProyecto;
    private javax.swing.JComboBox<String> cajaOpcionesTipoRepo;
    private javax.swing.JLabel jLabel1;
    private javax.swing.JLabel jLabel3;
    private javax.swing.JLabel lbRuta;
    private javax.swing.JTextField texNombreRepo;
    private javax.swing.JTextField txtRuta;
    // End of variables declaration//GEN-END:variables
}
