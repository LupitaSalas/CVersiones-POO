/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Controlador;

import Modelo.Archivo;
import Vista.FrmCrearProyecto;

/**
 *
 * @author lupit
 */
public class CtrlArchivo {
    private Archivo unArchivo;
    private FrmCrearProyecto unFrmCrearProyecto;
    
    //Metodos get
    public Archivo getUnArchivo() {
        return unArchivo;
    }

    public FrmCrearProyecto getUnFrmCrearProyecto() {
        return unFrmCrearProyecto;
    }
    
    //Medotos set
    public void setUnArchivo(Archivo unArchivo) {
        this.unArchivo = unArchivo;
    }

    public void setUnFrmCrearProyecto(FrmCrearProyecto unFrmCrearProyecto) {
        this.unFrmCrearProyecto = unFrmCrearProyecto;
    }
    
    public String BuscarArchivo(String ruta){
        return null;
        
    }
    
    
}
