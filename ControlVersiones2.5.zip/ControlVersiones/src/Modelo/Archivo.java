/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Modelo;
/**
 *
 * @author rekum
 */
public class Archivo extends Repositorio{
    private Fecha fecha;

    public Archivo(String nombre, String ubicacion,String tipo, Fecha fecha) {
        super(nombre, ubicacion, tipo);
        this.fecha = fecha;
    }

    public Fecha getFecha() {
        return fecha;
    }

    public void setFecha(Fecha fecha) {
        this.fecha = fecha;
    }
  
   }
            
            
            
    
   
