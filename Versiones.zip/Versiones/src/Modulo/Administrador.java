
package Modulo;


public class Administrador extends Usuario {
    
    public Administrador(String nombre, String apellidoPaterno, String apellidoMaterno, int clave){
        super(nombre, apellidoPaterno, apellidoMaterno, clave);
        
        
    }
    
    @Override
    public String toString() {
        return super.toString();
    }
}
