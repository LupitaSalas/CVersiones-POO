
package Modulo;


public class Editor extends Usuario {
    
    public Editor(String nombre, String apellidoPaterno, String apellidoMaterno, int clave){
        super(nombre, apellidoPaterno, apellidoMaterno, clave);
        
        
    }
    
    @Override
    public String toString() {
        return super.toString();
    }
}
